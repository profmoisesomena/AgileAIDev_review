
  # Meeting Flow - MPI

  This is a code bundle for Meeting Flow - MPI. The original project is available at https://www.figma.com/design/3tCLObNxWdhKP631PL2ucK/Meeting-Flow---MPI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  