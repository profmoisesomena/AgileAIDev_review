import { useState, useRef } from 'react';
import { Camera, Users, Check, X, AlertCircle, Scan, UserCheck } from 'lucide-react';
import { Button } from './Button';
import { Card, CardContent, CardHeader } from './Card';
import { Badge } from './Badge';
import type { Participant } from '../data/mockData';

interface DetectedFace {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  participantId?: string;
  confidence?: number;
}

interface FacialRecognitionUploadProps {
  participants: Participant[];
  onAttendanceMarked: (attendees: string[]) => void;
  selectedParticipants: string[];
}

export function FacialRecognitionUpload({
  participants,
  onAttendanceMarked,
  selectedParticipants,
}: FacialRecognitionUploadProps) {
  const [groupPhoto, setGroupPhoto] = useState<string | null>(null);
  const [detectedFaces, setDetectedFaces] = useState<DetectedFace[]>([]);
  const [processing, setProcessing] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [matchingProgress, setMatchingProgress] = useState<{participantId: string, progress: number}[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setGroupPhoto(event.target?.result as string);
        setShowResults(false);
        setDetectedFaces([]);
      };
      reader.readAsDataURL(file);
    }
  };

  // Simula o processo de reconhecimento facial
  const simulateFacialRecognition = () => {
    setProcessing(true);
    setShowResults(false);
    setMatchingProgress([]);

    // Fase 1: Simula a comparação com fotos de referência
    const matchingSteps = selectedParticipants.map((id, index) => ({
      participantId: id,
      progress: 0,
    }));
    setMatchingProgress(matchingSteps);

    // Simula o progresso de matching
    let progressInterval = setInterval(() => {
      setMatchingProgress((prev) =>
        prev.map((step) => ({
          ...step,
          progress: Math.min(step.progress + Math.random() * 30, 100),
        }))
      );
    }, 300);

    // Após simular o matching, mostra os resultados
    setTimeout(() => {
      clearInterval(progressInterval);
      
      // Simula detectar até o número de participantes selecionados
      const mockDetections: DetectedFace[] = [];
      const numFaces = Math.min(selectedParticipants.length, Math.floor(Math.random() * 2) + selectedParticipants.length);
      
      for (let i = 0; i < numFaces; i++) {
        const participantId = selectedParticipants[i];
        mockDetections.push({
          id: `face-${i}`,
          x: 10 + (i % 3) * 30,
          y: 15 + Math.floor(i / 3) * 35,
          width: 20,
          height: 28,
          participantId: participantId || undefined,
          confidence: participantId ? Math.random() * 0.15 + 0.85 : undefined,
        });
      }

      setDetectedFaces(mockDetections);
      setMatchingProgress([]);
      setProcessing(false);
      setShowResults(true);

      // Marca presença automaticamente
      const attendees = mockDetections
        .filter((face) => face.participantId)
        .map((face) => face.participantId!);
      
      onAttendanceMarked(attendees);
    }, 3000);
  };

  const getParticipantName = (participantId: string) => {
    return participants.find((p) => p.id === participantId)?.name || 'Desconhecido';
  };

  const updateFaceParticipant = (faceId: string, participantId: string | undefined) => {
    setDetectedFaces(
      detectedFaces.map((face) =>
        face.id === faceId ? { ...face, participantId } : face
      )
    );

    // Atualiza a lista de presença
    const attendees = detectedFaces
      .map((face) => (face.id === faceId ? participantId : face.participantId))
      .filter((id): id is string => !!id);
    
    onAttendanceMarked(attendees);
  };

  const confirmedCount = detectedFaces.filter((f) => f.participantId).length;
  const unconfirmedCount = detectedFaces.length - confirmedCount;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-semibold text-gray-900">
              Chamada por Reconhecimento Facial
            </h2>
          </div>
          {showResults && (
            <div className="flex gap-2">
              <Badge variant="success">{confirmedCount} identificados</Badge>
              {unconfirmedCount > 0 && (
                <Badge variant="warning">{unconfirmedCount} não identificados</Badge>
              )}
            </div>
          )}
        </div>
        <p className="text-sm text-gray-500 mt-1">
          Faça upload de uma foto em grupo para identificar automaticamente os participantes
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Reference Photos Display */}
        {selectedParticipants.length > 0 && !groupPhoto && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3 mb-3">
              <UserCheck className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-blue-900 mb-1">
                  Participantes selecionados para reconhecimento
                </p>
                <p className="text-xs text-blue-700">
                  O sistema comparará a foto do grupo com as fotos de referência destes participantes
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {participants
                .filter((p) => selectedParticipants.includes(p.id))
                .map((participant) => (
                  <div
                    key={participant.id}
                    className="flex flex-col items-center gap-2 p-2 bg-white rounded-lg"
                  >
                    <img
                      src={participant.photo}
                      alt={participant.name}
                      className="w-16 h-16 rounded-full object-cover border-2 border-blue-300"
                    />
                    <p className="text-xs font-medium text-gray-900 text-center">
                      {participant.name}
                    </p>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Upload Area */}
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handlePhotoUpload}
            className="hidden"
          />
          
          {!groupPhoto ? (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full p-8 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-400 hover:bg-blue-50 transition-all group"
            >
              <div className="flex flex-col items-center gap-3">
                <div className="p-3 bg-blue-100 rounded-full group-hover:bg-blue-200 transition-colors">
                  <Users className="w-8 h-8 text-blue-600" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-900">
                    Clique para fazer upload da foto em grupo
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    PNG, JPG ou JPEG até 10MB
                  </p>
                </div>
              </div>
            </button>
          ) : (
            <div className="space-y-4">
              {/* Image Preview with Face Detection Boxes */}
              <div className="relative inline-block w-full">
                <img
                  ref={imageRef}
                  src={groupPhoto}
                  alt="Foto do grupo"
                  className="w-full rounded-lg"
                />
                
                {/* Face detection boxes */}
                {showResults &&
                  detectedFaces.map((face) => (
                    <div
                      key={face.id}
                      className="absolute border-2 border-green-500 rounded"
                      style={{
                        left: `${face.x}%`,
                        top: `${face.y}%`,
                        width: `${face.width}%`,
                        height: `${face.height}%`,
                      }}
                    >
                      {/* Face label */}
                      <div className="absolute -top-8 left-0 right-0 flex justify-center">
                        <div className="bg-green-500 text-white px-2 py-1 rounded text-xs font-medium whitespace-nowrap shadow-lg">
                          {face.participantId
                            ? getParticipantName(face.participantId)
                            : 'Não identificado'}
                          {face.confidence && (
                            <span className="ml-1 opacity-75">
                              ({Math.round(face.confidence * 100)}%)
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                
                {processing && (
                  <div className="absolute inset-0 bg-black bg-opacity-50 rounded-lg flex items-center justify-center">
                    <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full mx-4">
                      <div className="text-center mb-4">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                        <p className="font-medium text-gray-900">Processando imagem...</p>
                        <p className="text-sm text-gray-500 mt-1">Detectando rostos e comparando com referências</p>
                      </div>
                      
                      {matchingProgress.length > 0 && (
                        <div className="space-y-2 mt-4">
                          <p className="text-xs font-medium text-gray-700 mb-2">
                            Comparando com fotos de referência:
                          </p>
                          {matchingProgress.map((item) => {
                            const participant = participants.find((p) => p.id === item.participantId);
                            return (
                              <div key={item.participantId} className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <img
                                    src={participant?.photo}
                                    alt={participant?.name}
                                    className="w-6 h-6 rounded-full object-cover"
                                  />
                                  <span className="text-xs text-gray-700 flex-1">
                                    {participant?.name}
                                  </span>
                                  <span className="text-xs font-medium text-blue-600">
                                    {Math.round(item.progress)}%
                                  </span>
                                </div>
                                <div className="w-full bg-gray-200 rounded-full h-1.5">
                                  <div
                                    className="bg-blue-600 h-1.5 rounded-full transition-all duration-300"
                                    style={{ width: `${item.progress}%` }}
                                  />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                {!showResults && !processing && (
                  <Button
                    type="button"
                    onClick={simulateFacialRecognition}
                    disabled={selectedParticipants.length === 0}
                    className="flex-1"
                  >
                    <Camera className="w-4 h-4 mr-2" />
                    Processar Reconhecimento Facial
                  </Button>
                )}
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => {
                    setGroupPhoto(null);
                    setDetectedFaces([]);
                    setShowResults(false);
                    if (fileInputRef.current) {
                      fileInputRef.current.value = '';
                    }
                  }}
                >
                  <X className="w-4 h-4 mr-2" />
                  Remover Foto
                </Button>
              </div>

              {/* Results - Manual Confirmation */}
              {showResults && detectedFaces.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-gray-700 bg-green-50 border border-green-200 rounded-lg p-3">
                    <Scan className="w-4 h-4 text-green-600" />
                    <span>
                      Reconhecimento concluído! Confirme ou ajuste as identificações abaixo:
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {detectedFaces.map((face, index) => {
                      const participant = participants.find((p) => p.id === face.participantId);
                      return (
                        <div
                          key={face.id}
                          className={`flex items-center gap-3 p-3 rounded-lg border-2 ${
                            face.participantId
                              ? 'bg-green-50 border-green-300'
                              : 'bg-yellow-50 border-yellow-300'
                          }`}
                        >
                          <div className="flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-600 rounded-full font-semibold text-sm flex-shrink-0">
                            {index + 1}
                          </div>
                          
                          {/* Reference Photo Preview */}
                          {participant && (
                            <img
                              src={participant.photo}
                              alt={participant.name}
                              className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-sm flex-shrink-0"
                            />
                          )}
                          
                          <select
                            value={face.participantId || ''}
                            onChange={(e) =>
                              updateFaceParticipant(
                                face.id,
                                e.target.value || undefined
                              )
                            }
                            className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                          >
                            <option value="">Não identificado</option>
                            {participants
                              .filter((p) => selectedParticipants.includes(p.id))
                              .map((p) => (
                                <option key={p.id} value={p.id}>
                                  {p.name}
                                  {face.participantId === p.id && face.confidence
                                    ? ` (${Math.round(face.confidence * 100)}%)`
                                    : ''}
                                </option>
                              ))}
                          </select>
                          {face.participantId ? (
                            <Check className="w-5 h-5 text-green-600 flex-shrink-0" />
                          ) : (
                            <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0" />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Info Banner */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-blue-900 mb-1">
                      Simulação de Reconhecimento Facial
                    </p>
                    <p className="text-blue-700">
                      Esta é uma demonstração. O sistema compara a foto do grupo com as fotos de referência
                      cadastradas no perfil de cada participante. Para reconhecimento facial real com IA,
                      conecte uma API de visão computacional como Azure Face API, AWS Rekognition
                      ou Google Cloud Vision.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}