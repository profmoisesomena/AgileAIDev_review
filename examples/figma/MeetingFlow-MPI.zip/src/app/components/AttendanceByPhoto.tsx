import { useState, useRef } from 'react';
import { Camera, Users, Check, X, Upload, UserCheck, Clock, AlertCircle } from 'lucide-react';
import { Button } from './Button';
import { Card, CardContent, CardHeader } from './Card';
import { Badge } from './Badge';
import type { Participant } from '../data/mockData';

interface DetectedFace {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  participantId: string;
  confidence: number;
  name: string;
}

interface AttendanceByPhotoProps {
  meetingId: string;
  participants: Participant[];
  onAttendanceConfirmed: (attendees: string[]) => void;
}

export function AttendanceByPhoto({
  meetingId,
  participants,
  onAttendanceConfirmed,
}: AttendanceByPhotoProps) {
  const [groupPhoto, setGroupPhoto] = useState<string | null>(null);
  const [detectedFaces, setDetectedFaces] = useState<DetectedFace[]>([]);
  const [processing, setProcessing] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [attendanceMarked, setAttendanceMarked] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setGroupPhoto(event.target?.result as string);
        setDetectedFaces([]);
        setAttendanceMarked(false);
        // Inicia processamento automaticamente
        setTimeout(() => processAttendance(event.target?.result as string), 500);
      };
      reader.readAsDataURL(file);
    }
  };

  const processAttendance = (photoUrl: string) => {
    setProcessing(true);
    setAnalyzing(true);

    // Simula análise da foto
    setTimeout(() => {
      setAnalyzing(false);

      // Simula detecção de rostos e identificação
      // Em produção, aqui seria a chamada para API de reconhecimento facial
      const numFacesToDetect = Math.min(
        participants.length,
        Math.max(2, Math.floor(Math.random() * participants.length))
      );

      const shuffledParticipants = [...participants].sort(() => Math.random() - 0.5);
      const detectedParticipants = shuffledParticipants.slice(0, numFacesToDetect);

      const mockDetections: DetectedFace[] = detectedParticipants.map((participant, i) => ({
        id: `face-${i}`,
        x: 10 + (i % 3) * 30,
        y: 15 + Math.floor(i / 3) * 35,
        width: 20,
        height: 28,
        participantId: participant.id,
        confidence: Math.random() * 0.12 + 0.88, // 88-100%
        name: participant.name,
      }));

      setDetectedFaces(mockDetections);
      setProcessing(false);

      // Marca presença automaticamente após 1 segundo
      setTimeout(() => {
        const attendeeIds = mockDetections.map((face) => face.participantId);
        onAttendanceConfirmed(attendeeIds);
        setAttendanceMarked(true);
      }, 1000);
    }, 3000);
  };

  const retakePhoto = () => {
    setGroupPhoto(null);
    setDetectedFaces([]);
    setAttendanceMarked(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const attendeeIds = detectedFaces.map((face) => face.participantId);
  const presentCount = attendeeIds.length;
  const absentCount = participants.length - presentCount;

  return (
    <div className="space-y-6">
      {/* Upload or Camera */}
      {!groupPhoto ? (
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Camera className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-semibold text-gray-900">
                Lista de Presença por Foto
              </h2>
            </div>
            <p className="text-sm text-gray-500 mt-1">
              Tire ou faça upload de uma foto do grupo para identificar automaticamente os participantes
            </p>
          </CardHeader>
          <CardContent>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handlePhotoUpload}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full p-12 border-2 border-dashed border-blue-300 rounded-xl hover:border-blue-400 hover:bg-blue-50 transition-all group"
            >
              <div className="flex flex-col items-center gap-4">
                <div className="p-4 bg-blue-100 rounded-full group-hover:bg-blue-200 transition-colors">
                  <Camera className="w-12 h-12 text-blue-600" />
                </div>
                <div className="text-center">
                  <p className="text-lg font-semibold text-gray-900 mb-1">
                    Tirar ou Enviar Foto do Grupo
                  </p>
                  <p className="text-sm text-gray-500">
                    O sistema identificará automaticamente quem está presente
                  </p>
                </div>
              </div>
            </button>

            {/* Expected Participants */}
            <div className="mt-6 bg-gray-50 rounded-lg p-4">
              <p className="text-sm font-medium text-gray-700 mb-3">
                Participantes esperados ({participants.length}):
              </p>
              <div className="flex flex-wrap gap-2">
                {participants.map((participant) => (
                  <div
                    key={participant.id}
                    className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border border-gray-200"
                  >
                    <img
                      src={participant.photo}
                      alt={participant.name}
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="text-sm text-gray-700">{participant.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Photo Analysis */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Camera className="w-5 h-5 text-blue-600" />
                  <h2 className="text-lg font-semibold text-gray-900">
                    Foto do Grupo
                  </h2>
                </div>
                {attendanceMarked && (
                  <Badge variant="success">
                    <Check className="w-4 h-4 mr-1" />
                    Presença Confirmada
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="relative inline-block w-full">
                <img
                  src={groupPhoto}
                  alt="Foto do grupo"
                  className="w-full rounded-lg"
                />

                {/* Face detection boxes */}
                {!processing &&
                  detectedFaces.map((face) => (
                    <div
                      key={face.id}
                      className="absolute border-3 border-green-500 rounded shadow-lg"
                      style={{
                        left: `${face.x}%`,
                        top: `${face.y}%`,
                        width: `${face.width}%`,
                        height: `${face.height}%`,
                      }}
                    >
                      {/* Face label */}
                      <div className="absolute -top-9 left-0 right-0 flex justify-center">
                        <div className="bg-green-500 text-white px-3 py-1.5 rounded-lg text-sm font-semibold whitespace-nowrap shadow-lg flex items-center gap-1">
                          <Check className="w-4 h-4" />
                          {face.name}
                          <span className="ml-1 opacity-90 text-xs">
                            {Math.round(face.confidence * 100)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}

                {/* Processing overlay */}
                {processing && (
                  <div className="absolute inset-0 bg-black bg-opacity-60 rounded-lg flex items-center justify-center">
                    <div className="bg-white p-8 rounded-xl shadow-2xl text-center max-w-sm">
                      {analyzing ? (
                        <>
                          <div className="relative mb-6">
                            <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-200 border-t-blue-600 mx-auto"></div>
                            <Camera className="w-8 h-8 text-blue-600 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
                          </div>
                          <p className="font-semibold text-gray-900 text-lg mb-2">
                            Analisando foto...
                          </p>
                          <p className="text-sm text-gray-600">
                            Detectando e identificando rostos
                          </p>
                        </>
                      ) : (
                        <>
                          <div className="mb-6">
                            <div className="relative inline-block">
                              <div className="animate-pulse rounded-full h-16 w-16 bg-green-100 mx-auto flex items-center justify-center">
                                <UserCheck className="w-8 h-8 text-green-600" />
                              </div>
                            </div>
                          </div>
                          <p className="font-semibold text-gray-900 text-lg mb-2">
                            Marcando presença...
                          </p>
                          <p className="text-sm text-gray-600">
                            {detectedFaces.length} participante(s) identificado(s)
                          </p>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-2 mt-4">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={retakePhoto}
                  className="flex-1"
                >
                  <X className="w-4 h-4 mr-2" />
                  Tirar Nova Foto
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Attendance Results */}
          {attendanceMarked && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-green-600" />
                  <h2 className="text-lg font-semibold text-gray-900">
                    Resultado da Chamada
                  </h2>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Summary */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <Check className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <p className="text-3xl font-bold text-green-600">
                          {presentCount}
                        </p>
                        <p className="text-sm text-green-700">Presentes</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-gray-100 rounded-lg">
                        <Clock className="w-6 h-6 text-gray-600" />
                      </div>
                      <div>
                        <p className="text-3xl font-bold text-gray-600">
                          {absentCount}
                        </p>
                        <p className="text-sm text-gray-700">Ausentes</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div>
                  <div className="flex justify-between text-sm text-gray-600 mb-2">
                    <span>Taxa de presença</span>
                    <span className="font-semibold">
                      {Math.round((presentCount / participants.length) * 100)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-green-600 h-3 rounded-full transition-all duration-500"
                      style={{
                        width: `${(presentCount / participants.length) * 100}%`,
                      }}
                    />
                  </div>
                </div>

                {/* Detailed List */}
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-700">
                    Lista Detalhada:
                  </p>
                  <div className="space-y-2">
                    {participants.map((participant) => {
                      const isPresent = attendeeIds.includes(participant.id);
                      const detection = detectedFaces.find(
                        (f) => f.participantId === participant.id
                      );

                      return (
                        <div
                          key={participant.id}
                          className={`flex items-center justify-between p-3 rounded-lg border-2 ${
                            isPresent
                              ? 'bg-green-50 border-green-300'
                              : 'bg-gray-50 border-gray-200'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <img
                              src={participant.photo}
                              alt={participant.name}
                              className="w-12 h-12 rounded-full object-cover"
                            />
                            <div>
                              <p className="font-medium text-gray-900">
                                {participant.name}
                              </p>
                              <p className="text-sm text-gray-500">
                                {participant.position}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            {isPresent ? (
                              <>
                                {detection && (
                                  <span className="text-xs text-green-700 bg-green-100 px-2 py-1 rounded">
                                    {Math.round(detection.confidence * 100)}% confiança
                                  </span>
                                )}
                                <div className="flex items-center gap-1 text-green-600 font-medium">
                                  <Check className="w-5 h-5" />
                                  <span>Presente</span>
                                </div>
                              </>
                            ) : (
                              <div className="flex items-center gap-1 text-gray-500">
                                <Clock className="w-5 h-5" />
                                <span>Ausente</span>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-800">
                <p className="font-medium mb-1">Como funciona:</p>
                <ul className="list-disc list-inside space-y-1 text-blue-700">
                  <li>A foto é analisada para detectar rostos</li>
                  <li>Cada rosto é comparado com as fotos de referência dos participantes</li>
                  <li>A presença é marcada automaticamente para correspondências com alta confiança</li>
                  <li>Em produção, use APIs como Azure Face, AWS Rekognition ou Google Vision</li>
                </ul>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
