import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Dashboard } from "./pages/Dashboard";
import { Regions } from "./pages/Regions";
import { Participants } from "./pages/Participants";
import { ParticipantForm } from "./pages/ParticipantForm";
import { Meetings } from "./pages/Meetings";
import { MeetingForm } from "./pages/MeetingForm";
import { MeetingView } from "./pages/MeetingView";
import { MeetingProcessing } from "./pages/MeetingProcessing";
import { AttendanceCheck } from "./pages/AttendanceCheck";
import { Minutes } from "./pages/Minutes";
import { Reports } from "./pages/Reports";
import { Settings } from "./pages/Settings";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "regions", Component: Regions },
      { path: "participants", Component: Participants },
      { path: "participants/new", Component: ParticipantForm },
      { path: "participants/:id/edit", Component: ParticipantForm },
      { path: "meetings", Component: Meetings },
      { path: "meetings/new", Component: MeetingForm },
      { path: "meetings/:id/edit", Component: MeetingForm },
      { path: "meetings/:id/processing", Component: MeetingProcessing },
      { path: "meetings/:id/attendance", Component: AttendanceCheck },
      { path: "meetings/:id", Component: MeetingView },
      { path: "minutes", Component: Minutes },
      { path: "reports", Component: Reports },
      { path: "settings", Component: Settings },
      { path: "*", Component: NotFound },
    ],
  },
]);