import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Card, CardHeader, CardContent } from '../components/Card';
import { Button } from '../components/Button';
import { Check, Clock, FileText } from 'lucide-react';

interface ProcessingStep {
  id: string;
  label: string;
  status: 'pending' | 'processing' | 'completed';
}

export function MeetingProcessing() {
  const navigate = useNavigate();
  const { id } = useParams();

  const [steps, setSteps] = useState<ProcessingStep[]>([
    { id: '1', label: 'Upload concluído', status: 'completed' },
    { id: '2', label: 'Transcrição em andamento', status: 'processing' },
    { id: '3', label: 'Geração da ata', status: 'pending' },
  ]);

  const [progress, setProgress] = useState(33);

  useEffect(() => {
    // Simulate processing
    const timer1 = setTimeout(() => {
      setSteps([
        { id: '1', label: 'Upload concluído', status: 'completed' },
        { id: '2', label: 'Transcrição em andamento', status: 'completed' },
        { id: '3', label: 'Geração da ata', status: 'processing' },
      ]);
      setProgress(66);
    }, 3000);

    const timer2 = setTimeout(() => {
      setSteps([
        { id: '1', label: 'Upload concluído', status: 'completed' },
        { id: '2', label: 'Transcrição em andamento', status: 'completed' },
        { id: '3', label: 'Geração da ata', status: 'completed' },
      ]);
      setProgress(100);
    }, 6000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, []);

  const isComplete = progress === 100;

  return (
    <div className="min-h-screen flex items-center justify-center p-8 bg-gray-50">
      <Card className="max-w-2xl w-full">
        <CardHeader>
          <h1 className="text-2xl font-semibold text-gray-900 text-center">
            Processando Reunião
          </h1>
          <p className="text-gray-500 text-center mt-2">
            Estamos processando os conteúdos da reunião. Isso pode levar alguns minutos.
          </p>
        </CardHeader>
        <CardContent className="py-8">
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Progresso</span>
              <span className="text-sm font-medium text-gray-900">{progress}%</span>
            </div>
            <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-600 transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Processing Steps */}
          <div className="space-y-4 mb-8">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center gap-4">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                    step.status === 'completed'
                      ? 'bg-green-100'
                      : step.status === 'processing'
                      ? 'bg-blue-100'
                      : 'bg-gray-100'
                  }`}
                >
                  {step.status === 'completed' ? (
                    <Check className="w-5 h-5 text-green-600" />
                  ) : step.status === 'processing' ? (
                    <Clock className="w-5 h-5 text-blue-600 animate-pulse" />
                  ) : (
                    <FileText className="w-5 h-5 text-gray-400" />
                  )}
                </div>
                <div className="flex-1">
                  <p
                    className={`font-medium ${
                      step.status === 'completed'
                        ? 'text-green-900'
                        : step.status === 'processing'
                        ? 'text-blue-900'
                        : 'text-gray-500'
                    }`}
                  >
                    {step.label}
                  </p>
                  <p className="text-sm text-gray-500">
                    {step.status === 'completed'
                      ? 'Concluído'
                      : step.status === 'processing'
                      ? 'Em andamento...'
                      : 'Aguardando'}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Action Buttons */}
          {isComplete && (
            <div className="space-y-3">
              <Button
                className="w-full"
                size="lg"
                onClick={() => navigate(`/meetings/${id}`)}
              >
                Visualizar Reunião
              </Button>
              <Button
                className="w-full"
                variant="secondary"
                onClick={() => navigate('/meetings')}
              >
                Voltar para Reuniões
              </Button>
            </div>
          )}

          {!isComplete && (
            <div className="text-center text-sm text-gray-500">
              Aguarde enquanto processamos os dados...
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
