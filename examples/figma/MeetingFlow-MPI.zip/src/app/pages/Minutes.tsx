import { useState } from 'react';
import { Link } from 'react-router';
import { Card, CardHeader, CardContent } from '../components/Card';
import { Badge } from '../components/Badge';
import { Select } from '../components/Select';
import { Eye, Download, CheckCircle } from 'lucide-react';
import { Button } from '../components/Button';
import { minutes, regions } from '../data/mockData';

export function Minutes() {
  const [selectedRegion, setSelectedRegion] = useState('all');

  const filteredMinutes = minutes.filter((m) => {
    const matchesRegion = selectedRegion === 'all' || m.region === selectedRegion;
    return matchesRegion;
  });

  const regionOptions = [
    { value: 'all', label: 'Todas as regiões' },
    ...regions.map((r) => ({ value: r.name, label: r.name })),
  ];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">Atas</h1>
        <p className="text-gray-500 mt-1">Visualize e gerencie as atas das reuniões</p>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="py-4">
          <div className="max-w-xs">
            <Select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              options={regionOptions}
            />
          </div>
        </CardContent>
      </Card>

      {/* Minutes Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredMinutes.map((minute) => (
          <Card key={minute.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-2">{minute.meetingTitle}</h3>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span>{minute.region}</span>
                    <span>•</span>
                    <span>{formatDate(minute.date)}</span>
                  </div>
                </div>
                {minute.approved && (
                  <Badge variant="success">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Aprovada
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Pauta</p>
                  <p className="text-sm text-gray-600 line-clamp-2">{minute.agenda}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Resumo</p>
                  <p className="text-sm text-gray-600 line-clamp-3">{minute.summary}</p>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Decisões</p>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {minute.decisions.slice(0, 2).map((decision, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-blue-600 mt-1">•</span>
                        <span className="line-clamp-1">{decision}</span>
                      </li>
                    ))}
                    {minute.decisions.length > 2 && (
                      <li className="text-gray-500 text-xs">
                        +{minute.decisions.length - 2} mais
                      </li>
                    )}
                  </ul>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Encaminhamentos</p>
                  <p className="text-sm text-gray-600">{minute.actions.length} ações definidas</p>
                </div>

                <div className="flex gap-2 pt-2">
                  <Link to={`/meetings/${minute.meetingId}`} className="flex-1">
                    <Button variant="secondary" className="w-full" size="sm">
                      <Eye className="w-4 h-4 mr-1" />
                      Visualizar
                    </Button>
                  </Link>
                  <Button variant="ghost" size="sm">
                    <Download className="w-4 h-4 mr-1" />
                    PDF
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredMinutes.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-gray-500">Nenhuma ata encontrada</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
