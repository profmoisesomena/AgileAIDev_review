import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Card, CardHeader, CardContent } from '../components/Card';
import { Button } from '../components/Button';
import { Select } from '../components/Select';
import { Badge } from '../components/Badge';
import { Plus, Eye, Edit, Camera } from 'lucide-react';
import { meetings, regions } from '../data/mockData';

export function Meetings() {
  const navigate = useNavigate();
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  const filteredMeetings = meetings.filter((m) => {
    const matchesRegion = selectedRegion === 'all' || m.region === selectedRegion;
    const matchesStatus = selectedStatus === 'all' || m.status === selectedStatus;
    return matchesRegion && matchesStatus;
  });

  const regionOptions = [
    { value: 'all', label: 'Todas as regiões' },
    ...regions.map((r) => ({ value: r.name, label: r.name })),
  ];

  const statusOptions = [
    { value: 'all', label: 'Todos os status' },
    { value: 'completed', label: 'Concluída' },
    { value: 'processing', label: 'Processando' },
    { value: 'pending', label: 'Pendente' },
    { value: 'error', label: 'Erro' },
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge variant="success">Concluída</Badge>;
      case 'processing':
        return <Badge variant="warning">Processando</Badge>;
      case 'error':
        return <Badge variant="error">Erro</Badge>;
      default:
        return <Badge variant="default">Pendente</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-semibold text-gray-900">Reuniões</h1>
          <p className="text-gray-500 mt-1">Gerencie todas as reuniões regionais</p>
        </div>
        <Link to="/meetings/new">
          <Button size="lg">
            <Plus className="w-5 h-5 mr-2" />
            Nova Reunião
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <Card className="mb-6">
        <CardContent className="py-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              options={regionOptions}
            />
            <Select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              options={statusOptions}
            />
          </div>
        </CardContent>
      </Card>

      {/* Meetings Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Título
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Região
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Local
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredMeetings.map((meeting) => (
                <tr key={meeting.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="font-medium text-gray-900">{meeting.title}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-900">{meeting.region}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-500">{formatDate(meeting.date)}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-500">{meeting.location}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {getStatusBadge(meeting.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => navigate(`/meetings/${meeting.id}/attendance`)}
                      >
                        <Camera className="w-4 h-4 mr-1" />
                        Chamada
                      </Button>
                      {meeting.status === 'processing' ? (
                        <Link to={`/meetings/${meeting.id}/processing`}>
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4 mr-1" />
                            Status
                          </Button>
                        </Link>
                      ) : meeting.status === 'completed' ? (
                        <Link to={`/meetings/${meeting.id}`}>
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4 mr-1" />
                            Visualizar
                          </Button>
                        </Link>
                      ) : (
                        <Link to={`/meetings/${meeting.id}/edit`}>
                          <Button variant="ghost" size="sm">
                            <Edit className="w-4 h-4 mr-1" />
                            Editar
                          </Button>
                        </Link>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredMeetings.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">Nenhuma reunião encontrada</p>
          </div>
        )}
      </Card>
    </div>
  );
}