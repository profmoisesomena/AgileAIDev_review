import { Link } from 'react-router';
import { Button } from '../components/Button';
import { Home } from 'lucide-react';

export function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center p-8">
      <div className="text-center">
        <h1 className="text-9xl font-bold text-gray-200">404</h1>
        <h2 className="text-3xl font-semibold text-gray-900 mt-4 mb-2">
          Página não encontrada
        </h2>
        <p className="text-gray-500 mb-8">
          Desculpe, não conseguimos encontrar a página que você está procurando.
        </p>
        <Link to="/">
          <Button size="lg">
            <Home className="w-5 h-5 mr-2" />
            Voltar ao Dashboard
          </Button>
        </Link>
      </div>
    </div>
  );
}
