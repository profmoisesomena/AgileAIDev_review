import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Card, CardHeader, CardContent } from '../components/Card';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { Select } from '../components/Select';
import { FileUpload } from '../components/FileUpload';
import { FacialRecognitionUpload } from '../components/FacialRecognitionUpload';
import { ArrowLeft, X, Upload, Camera } from 'lucide-react';
import { regions, participants, meetings } from '../data/mockData';
import { toast } from 'sonner';

export function MeetingForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = !!id;

  const existingMeeting = isEditing ? meetings.find(m => m.id === id) : null;

  const [formData, setFormData] = useState({
    title: existingMeeting?.title || '',
    region: existingMeeting?.region || '',
    date: existingMeeting?.date?.substring(0, 16) || '',
    location: existingMeeting?.location || '',
    participants: existingMeeting?.participants || [],
    attendees: existingMeeting?.attendees || [],
    text: '',
  });

  const [photoPreview, setPhotoPreview] = useState<string[]>([]);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newPreviews: string[] = [];
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          newPreviews.push(reader.result as string);
          if (newPreviews.length === files.length) {
            setPhotoPreview([...photoPreview, ...newPreviews]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removePhoto = (index: number) => {
    setPhotoPreview(photoPreview.filter((_, i) => i !== index));
  };

  const toggleParticipant = (participantId: string) => {
    if (formData.participants.includes(participantId)) {
      setFormData({
        ...formData,
        participants: formData.participants.filter(id => id !== participantId),
      });
    } else {
      setFormData({
        ...formData,
        participants: [...formData.participants, participantId],
      });
    }
  };

  const handleAttendanceMarked = (attendees: string[]) => {
    setFormData({
      ...formData,
      attendees: attendees,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Navigate to processing page
    navigate('/meetings/1/processing');
  };

  const handleGoToAttendance = () => {
    // Se for edição, vai direto para a página de chamada
    if (isEditing && id) {
      navigate(`/meetings/${id}/attendance`);
    } else {
      // Se for novo, precisa salvar primeiro (simulado)
      toast.warning('Salve a reunião primeiro', {
        description: 'Você precisa salvar a reunião antes de fazer a chamada por foto.',
      });
    }
  };

  const regionOptions = [
    { value: '', label: 'Selecione uma região' },
    ...regions.map((r) => ({ value: r.name, label: r.name })),
  ];

  return (
    <div className="p-8">
      <button
        onClick={() => navigate('/meetings')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        Voltar para reuniões
      </button>

      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">
          {isEditing ? 'Editar Reunião' : 'Nova Reunião'}
        </h1>
        <p className="text-gray-500 mt-1">
          {isEditing ? 'Atualize as informações da reunião' : 'Crie uma nova reunião e adicione conteúdos'}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <Card>
          <CardHeader>
            <h2 className="text-lg font-semibold text-gray-900">Informações Básicas</h2>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <Input
                  label="Título da Reunião"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Ex: Planejamento Trimestral 2026"
                  required
                />
              </div>
              <Select
                label="Região"
                value={formData.region}
                onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                options={regionOptions}
                required
              />
              <Input
                label="Data e Hora"
                type="datetime-local"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                required
              />
              <div className="md:col-span-2">
                <Input
                  label="Local"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="Ex: Sala de Conferências Porto Alegre"
                  required
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Participants */}
        <Card>
          <CardHeader>
            <h2 className="text-lg font-semibold text-gray-900">Participantes</h2>
          </CardHeader>
          <CardContent className="space-y-4">
            {formData.participants.length > 0 && (
              <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Camera className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">
                        Fazer Chamada por Reconhecimento Facial
                      </p>
                      <p className="text-sm text-gray-600">
                        {formData.participants.length} participante(s) selecionado(s) • Tire uma foto do grupo
                      </p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="default"
                    size="lg"
                    onClick={handleGoToAttendance}
                  >
                    <Camera className="w-5 h-5 mr-2" />
                    Abrir Câmera
                  </Button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {participants.map((participant) => (
                <label
                  key={participant.id}
                  className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                    formData.participants.includes(participant.id)
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={formData.participants.includes(participant.id)}
                    onChange={() => toggleParticipant(participant.id)}
                    className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                  />
                  <img
                    src={participant.photo}
                    alt={participant.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">
                      {participant.name}
                    </p>
                    <p className="text-xs text-gray-500 truncate">{participant.position}</p>
                  </div>
                </label>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Facial Recognition - Attendance Marking */}
        {formData.participants.length > 0 && (
          <FacialRecognitionUpload
            participants={participants}
            selectedParticipants={formData.participants}
            onAttendanceMarked={handleAttendanceMarked}
          />
        )}

        {/* Attendance Summary */}
        {formData.attendees.length > 0 && (
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold text-gray-900">
                Resumo de Presença
              </h2>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-4">
                <div className="text-2xl font-bold text-green-600">
                  {formData.attendees.length}
                </div>
                <div className="text-gray-600">
                  de {formData.participants.length} participantes presentes
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {formData.participants.map((participantId) => {
                  const participant = participants.find((p) => p.id === participantId);
                  const isPresent = formData.attendees.includes(participantId);
                  
                  return (
                    <div
                      key={participantId}
                      className={`flex items-center gap-3 p-3 rounded-lg border ${
                        isPresent
                          ? 'border-green-500 bg-green-50'
                          : 'border-gray-200 bg-gray-50'
                      }`}
                    >
                      <img
                        src={participant?.photo}
                        alt={participant?.name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-gray-900 text-sm truncate">
                          {participant?.name}
                        </p>
                        <p className={`text-xs ${isPresent ? 'text-green-600' : 'text-gray-500'}`}>
                          {isPresent ? '✓ Presente' : 'Ausente'}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Upload Content */}
        <Card>
          <CardHeader>
            <h2 className="text-lg font-semibold text-gray-900">Upload de Conteúdos</h2>
          </CardHeader>
          <CardContent className="space-y-6">
            <FileUpload label="Vídeo da Reunião" accept="video/*" />
            <FileUpload label="Áudio da Reunião" accept="audio/*" />
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Texto Manual (Transcrição)
              </label>
              <textarea
                value={formData.text}
                onChange={(e) => setFormData({ ...formData, text: e.target.value })}
                rows={8}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Cole ou digite a transcrição da reunião..."
              />
            </div>
          </CardContent>
        </Card>

        {/* Photos */}
        <Card>
          <CardHeader>
            <h2 className="text-lg font-semibold text-gray-900">Fotos da Reunião</h2>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <label className="cursor-pointer">
                <div className="flex items-center justify-center gap-2 px-4 py-3 bg-white border-2 border-dashed border-gray-300 rounded-lg hover:border-gray-400 transition-colors">
                  <Upload className="w-5 h-5 text-gray-400" />
                  <span className="text-sm font-medium text-gray-700">
                    Selecionar Fotos
                  </span>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handlePhotoChange}
                  className="hidden"
                />
              </label>
            </div>

            {photoPreview.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {photoPreview.map((preview, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={preview}
                      alt={`Preview ${index + 1}`}
                      className="w-full h-32 object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => removePhoto(index)}
                      className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4">
          <Button
            type="button"
            variant="secondary"
            onClick={() => navigate('/meetings')}
          >
            Cancelar
          </Button>
          <Button type="submit">
            Processar Reunião
          </Button>
        </div>
      </form>
    </div>
  );
}