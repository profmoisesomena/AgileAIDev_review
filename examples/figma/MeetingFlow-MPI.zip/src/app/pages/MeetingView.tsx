import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Card, CardHeader, CardContent } from '../components/Card';
import { Button } from '../components/Button';
import { Badge } from '../components/Badge';
import { 
  ArrowLeft, 
  Download, 
  Edit, 
  Calendar, 
  MapPin, 
  Users,
  CheckCircle,
  Clock,
  UserCheck,
  Camera,
} from 'lucide-react';
import { meetings, participants, minutes } from '../data/mockData';

export function MeetingView() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState<'transcription' | 'minute'>('transcription');

  const meeting = meetings.find(m => m.id === id);
  const minute = minutes.find(m => m.meetingId === id);
  const meetingParticipants = participants.filter(p => 
    meeting?.participants.includes(p.id)
  );
  const attendees = participants.filter(p =>
    meeting?.attendees?.includes(p.id)
  );

  if (!meeting) {
    return (
      <div className="p-8">
        <p className="text-gray-500">Reunião não encontrada</p>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const sampleTranscription = `[00:00] Ana Silva: Bom dia a todos! Vamos iniciar nossa reunião de planejamento trimestral. 

[00:15] Carlos Santos: Bom dia! Preparei a apresentação com os dados do último trimestre.

[00:30] Ana Silva: Perfeito. Primeiro, gostaria de revisar nossos principais objetivos para este trimestre. Temos três prioridades: aumentar nossa presença regional, otimizar processos internos e fortalecer a equipe.

[01:20] Carlos Santos: Sobre a otimização de processos, identificamos que podemos reduzir em 20% o tempo de resposta implementando o novo sistema de gestão.

[02:00] Ana Silva: Excelente ponto. Precisamos definir o orçamento para essa implementação. Sugiro aumentarmos em 15% o orçamento de tecnologia.

[02:45] Carlos Santos: Concordo. Também precisamos considerar a contratação de novos analistas para suportar o crescimento.

[03:20] Ana Silva: Sim, vamos incluir a aprovação para 3 novas contratações na pauta da próxima reunião com a diretoria.

[04:00] Carlos Santos: Perfeito. Vou preparar a proposta detalhada até o final da semana.

[04:30] Ana Silva: Ótimo. Alguma outra questão antes de encerrarmos?

[05:00] Carlos Santos: Não, acho que cobrimos tudo.

[05:15] Ana Silva: Então está encerrada nossa reunião. Obrigada a todos!`;

  return (
    <div className="p-8">
      <button
        onClick={() => navigate('/meetings')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        Voltar para reuniões
      </button>

      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900 mb-2">{meeting.title}</h1>
        <div className="flex items-center gap-6 text-gray-500">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span className="text-sm">{formatDate(meeting.date)}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{meeting.location}</span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3 mb-6">
        <Button
          onClick={() => navigate(`/meetings/${id}/attendance`)}
          variant="default"
          size="lg"
        >
          <Camera className="w-5 h-5 mr-2" />
          Fazer Chamada por Foto
        </Button>
        <Button
          onClick={() => navigate(`/meetings/${id}/edit`)}
          variant="secondary"
          size="lg"
        >
          <Edit className="w-5 h-5 mr-2" />
          Editar Reunião
        </Button>
        {!meeting.attendees && (
          <Badge variant="warning" className="flex items-center">
            <Clock className="w-4 h-4 mr-1" />
            Presença não registrada
          </Badge>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Column 1: Meeting Info */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold text-gray-900">Informações</h2>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-gray-500 mb-1">Região</p>
                <p className="font-medium text-gray-900">{meeting.region}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Status</p>
                <Badge variant="success">Concluída</Badge>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Conteúdos</p>
                <div className="flex flex-wrap gap-2">
                  {meeting.hasVideo && <Badge variant="info">Vídeo</Badge>}
                  {meeting.hasAudio && <Badge variant="info">Áudio</Badge>}
                  {meeting.hasText && <Badge variant="info">Texto</Badge>}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-900">Participantes</h2>
                <Users className="w-5 h-5 text-gray-400" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {meetingParticipants.map((participant) => (
                  <div key={participant.id} className="flex items-center gap-3">
                    <img
                      src={participant.photo}
                      alt={participant.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 text-sm truncate">
                        {participant.name}
                      </p>
                      <p className="text-xs text-gray-500 truncate">
                        {participant.position}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Attendance Card */}
          {meeting.attendees && meeting.attendees.length > 0 && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold text-gray-900">Presença</h2>
                  <UserCheck className="w-5 h-5 text-green-600" />
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  Confirmada por reconhecimento facial
                </p>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-green-600">
                      {meeting.attendees.length}
                    </span>
                    <span className="text-gray-600">
                      de {meeting.participants.length} presentes
                    </span>
                  </div>
                  <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-green-600 h-2 rounded-full"
                      style={{
                        width: `${(meeting.attendees.length / meeting.participants.length) * 100}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  {meetingParticipants.map((participant) => {
                    const isPresent = meeting.attendees?.includes(participant.id);
                    return (
                      <div
                        key={participant.id}
                        className={`flex items-center gap-3 p-2 rounded-lg ${
                          isPresent ? 'bg-green-50' : 'bg-gray-50'
                        }`}
                      >
                        <img
                          src={participant.photo}
                          alt={participant.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-900 text-sm truncate">
                            {participant.name}
                          </p>
                        </div>
                        {isPresent ? (
                          <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                        ) : (
                          <Clock className="w-5 h-5 text-gray-400 flex-shrink-0" />
                        )}
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {meeting.photos && meeting.photos.length > 0 && (
            <Card>
              <CardHeader>
                <h2 className="text-lg font-semibold text-gray-900">Fotos</h2>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2">
                  {meeting.photos.map((photo, index) => (
                    <img
                      key={index}
                      src={photo}
                      alt={`Foto ${index + 1}`}
                      className="w-full h-24 object-cover rounded-lg"
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Column 2: Transcription */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex gap-4">
                <button
                  onClick={() => setActiveTab('transcription')}
                  className={`pb-2 px-1 font-medium text-sm border-b-2 transition-colors ${
                    activeTab === 'transcription'
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Transcrição
                </button>
                <button
                  onClick={() => setActiveTab('minute')}
                  className={`pb-2 px-1 font-medium text-sm border-b-2 transition-colors ${
                    activeTab === 'minute'
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Ata Gerada
                </button>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="sm">
                  <Edit className="w-4 h-4 mr-1" />
                  Editar
                </Button>
                <Button variant="ghost" size="sm">
                  <Download className="w-4 h-4 mr-1" />
                  Exportar PDF
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {activeTab === 'transcription' ? (
              <div className="prose max-w-none">
                <textarea
                  className="w-full h-96 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                  defaultValue={sampleTranscription}
                />
              </div>
            ) : (
              <div className="space-y-6">
                {minute && (
                  <>
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Pauta</h3>
                      <p className="text-gray-700">{minute.agenda}</p>
                    </div>

                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Resumo</h3>
                      <p className="text-gray-700">{minute.summary}</p>
                    </div>

                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Decisões</h3>
                      <ul className="space-y-2">
                        {minute.decisions.map((decision, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                            <span className="text-gray-700">{decision}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Encaminhamentos</h3>
                      <div className="space-y-3">
                        {minute.actions.map((action, index) => (
                          <div key={index} className="p-3 bg-gray-50 rounded-lg">
                            <p className="text-gray-900 font-medium mb-2">{action.description}</p>
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <div className="flex items-center gap-1">
                                <Users className="w-4 h-4" />
                                <span>{action.responsible}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="w-4 h-4" />
                                <span>
                                  {new Date(action.deadline).toLocaleDateString('pt-BR')}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 border-t border-gray-200">
                      {minute.approved ? (
                        <div className="flex items-center gap-2 text-green-600">
                          <CheckCircle className="w-5 h-5" />
                          <span className="font-medium">Ata aprovada</span>
                        </div>
                      ) : (
                        <Button>Aprovar Ata</Button>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}