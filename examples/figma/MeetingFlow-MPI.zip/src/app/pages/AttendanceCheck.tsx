import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Card, CardHeader, CardContent } from '../components/Card';
import { Button } from '../components/Button';
import { AttendanceByPhoto } from '../components/AttendanceByPhoto';
import { ArrowLeft, Calendar, MapPin, Users, Save } from 'lucide-react';
import { meetings, participants } from '../data/mockData';
import { toast } from 'sonner';

export function AttendanceCheck() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [attendees, setAttendees] = useState<string[]>([]);
  const [saved, setSaved] = useState(false);

  const meeting = meetings.find((m) => m.id === id);
  const meetingParticipants = participants.filter((p) =>
    meeting?.participants.includes(p.id)
  );

  if (!meeting) {
    return (
      <div className="p-8">
        <p className="text-gray-500">Reunião não encontrada</p>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleAttendanceConfirmed = (attendeeIds: string[]) => {
    setAttendees(attendeeIds);
  };

  const handleSaveAttendance = () => {
    // Em produção, aqui seria a chamada para salvar no backend
    console.log('Salvando presença:', attendees);
    
    // Simula salvamento
    toast.success('Lista de presença salva com sucesso!', {
      description: `${attendees.length} participantes presentes registrados.`,
    });
    
    setSaved(true);
    
    // Redireciona após 2 segundos
    setTimeout(() => {
      navigate(`/meetings/${id}`);
    }, 2000);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <button
        onClick={() => navigate(`/meetings/${id}`)}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        Voltar para a reunião
      </button>

      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900 mb-2">
          Lista de Presença
        </h1>
        <p className="text-gray-500">
          Use reconhecimento facial para marcar presença automaticamente
        </p>
      </div>

      {/* Meeting Info */}
      <Card className="mb-6">
        <CardHeader>
          <h2 className="text-lg font-semibold text-gray-900">
            Informações da Reunião
          </h2>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-500 mb-1">Título</p>
              <p className="font-medium text-gray-900">{meeting.title}</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-gray-500 mb-1">Data e Hora</p>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <p className="text-sm text-gray-900">{formatDate(meeting.date)}</p>
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Local</p>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gray-400" />
                  <p className="text-sm text-gray-900">{meeting.location}</p>
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Participantes Esperados</p>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-gray-400" />
                  <p className="text-sm text-gray-900">
                    {meetingParticipants.length} pessoas
                  </p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Attendance Component */}
      <AttendanceByPhoto
        meetingId={meeting.id}
        participants={meetingParticipants}
        onAttendanceConfirmed={handleAttendanceConfirmed}
      />

      {/* Save Button */}
      {attendees.length > 0 && !saved && (
        <div className="mt-6 flex justify-end">
          <Button onClick={handleSaveAttendance} size="lg">
            <Save className="w-5 h-5 mr-2" />
            Salvar Lista de Presença
          </Button>
        </div>
      )}
    </div>
  );
}
