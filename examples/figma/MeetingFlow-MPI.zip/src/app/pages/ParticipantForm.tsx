import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Card, CardHeader, CardContent } from '../components/Card';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { Select } from '../components/Select';
import { ArrowLeft, Upload, User, Camera, AlertCircle } from 'lucide-react';
import { regions, participants } from '../data/mockData';

export function ParticipantForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = !!id;

  const existingParticipant = isEditing 
    ? participants.find(p => p.id === id) 
    : null;

  const [formData, setFormData] = useState({
    name: existingParticipant?.name || '',
    email: existingParticipant?.email || '',
    phone: existingParticipant?.phone || '',
    region: existingParticipant?.region || '',
    position: existingParticipant?.position || '',
    status: existingParticipant?.status || 'active',
  });

  const [photoPreview, setPhotoPreview] = useState<string | null>(
    existingParticipant?.photo || null
  );

  const [faceReferencePhotos, setFaceReferencePhotos] = useState<string[]>([]);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFaceReferenceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newPreviews: string[] = [];
      Array.from(files).forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          newPreviews.push(reader.result as string);
          if (newPreviews.length === files.length) {
            setFaceReferencePhotos([...faceReferencePhotos, ...newPreviews]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeFaceReference = (index: number) => {
    setFaceReferencePhotos(faceReferencePhotos.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically send the data to your backend
    console.log('Form submitted:', formData);
    navigate('/participants');
  };

  const regionOptions = [
    { value: '', label: 'Selecione uma região' },
    ...regions.map((r) => ({ value: r.name, label: r.name })),
  ];

  const statusOptions = [
    { value: 'active', label: 'Ativo' },
    { value: 'inactive', label: 'Inativo' },
  ];

  return (
    <div className="p-8">
      <button
        onClick={() => navigate('/participants')}
        className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5" />
        Voltar para participantes
      </button>

      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">
          {isEditing ? 'Editar Participante' : 'Novo Participante'}
        </h1>
        <p className="text-gray-500 mt-1">
          {isEditing ? 'Atualize as informações do participante' : 'Adicione um novo participante ao sistema'}
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <h2 className="text-lg font-semibold text-gray-900">Informações do Participante</h2>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Photo Upload */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Foto do Perfil
                </label>
                <div className="flex items-center gap-6">
                  <div className="w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden">
                    {photoPreview ? (
                      <img src={photoPreview} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <User className="w-12 h-12 text-gray-400" />
                    )}
                  </div>
                  <div>
                    <label className="cursor-pointer">
                      <div className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                        <Upload className="w-4 h-4" />
                        <span className="text-sm font-medium">Upload de Foto</span>
                      </div>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoChange}
                        className="hidden"
                      />
                    </label>
                    <p className="text-xs text-gray-500 mt-2">JPG, PNG ou GIF. Máximo 5MB.</p>
                  </div>
                </div>
              </div>

              {/* Face Recognition Reference Photos */}
              <div className="border-t border-gray-200 pt-6">
                <div className="flex items-start gap-3 mb-4">
                  <Camera className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-900 mb-1">
                      Fotos de Referência para Reconhecimento Facial
                    </label>
                    <p className="text-xs text-gray-500 mb-3">
                      Adicione múltiplas fotos do rosto do participante para melhorar a precisão do reconhecimento automático em reuniões
                    </p>
                  </div>
                </div>

                {/* Upload Button */}
                <label className="cursor-pointer">
                  <div className="flex items-center justify-center gap-2 px-4 py-3 bg-blue-50 border-2 border-dashed border-blue-300 rounded-lg hover:bg-blue-100 transition-colors">
                    <Camera className="w-5 h-5 text-blue-600" />
                    <span className="text-sm font-medium text-blue-700">
                      Adicionar Fotos de Referência
                    </span>
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleFaceReferenceChange}
                    className="hidden"
                  />
                </label>

                {/* Reference Photos Grid */}
                {faceReferencePhotos.length > 0 && (
                  <div className="mt-4 grid grid-cols-3 md:grid-cols-5 gap-3">
                    {faceReferencePhotos.map((photo, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={photo}
                          alt={`Referência ${index + 1}`}
                          className="w-full h-24 object-cover rounded-lg border-2 border-blue-200"
                        />
                        <button
                          type="button"
                          onClick={() => removeFaceReference(index)}
                          className="absolute top-1 right-1 p-1 bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Upload className="w-3 h-3 rotate-180" />
                        </button>
                        <div className="absolute bottom-1 left-1 right-1 bg-black bg-opacity-60 text-white text-xs text-center py-0.5 rounded">
                          Ref {index + 1}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Info Banner */}
                <div className="mt-4 bg-amber-50 border border-amber-200 rounded-lg p-3">
                  <div className="flex gap-2">
                    <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-xs text-amber-800">
                      <p className="font-medium mb-1">Dicas para melhores resultados:</p>
                      <ul className="list-disc list-inside space-y-0.5">
                        <li>Use fotos de boa qualidade com o rosto bem visível</li>
                        <li>Inclua fotos de diferentes ângulos e iluminações</li>
                        <li>Evite fotos com óculos escuros ou máscaras</li>
                        <li>3-5 fotos de referência são ideais para boa precisão</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Form Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input
                  label="Nome Completo"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Digite o nome completo"
                  required
                />

                <Input
                  label="E-mail"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="email@exemplo.com"
                  required
                />

                <Input
                  label="Telefone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="(00) 00000-0000"
                  required
                />

                <Select
                  label="Região"
                  value={formData.region}
                  onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                  options={regionOptions}
                  required
                />

                <Input
                  label="Cargo/Função"
                  value={formData.position}
                  onChange={(e) => setFormData({ ...formData, position: e.target.value })}
                  placeholder="Ex: Coordenador Regional"
                  required
                />

                <Select
                  label="Status"
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  options={statusOptions}
                  required
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4 mt-6">
          <Button
            type="button"
            variant="secondary"
            onClick={() => navigate('/participants')}
          >
            Cancelar
          </Button>
          <Button type="submit">
            {isEditing ? 'Salvar Alterações' : 'Adicionar Participante'}
          </Button>
        </div>
      </form>
    </div>
  );
}