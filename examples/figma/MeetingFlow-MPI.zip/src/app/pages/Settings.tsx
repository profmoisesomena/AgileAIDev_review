import { useState } from 'react';
import { Card, CardHeader, CardContent } from '../components/Card';
import { Button } from '../components/Button';
import { Input } from '../components/Input';
import { Select } from '../components/Select';
import { Bell, Lock, User, Globe } from 'lucide-react';

export function Settings() {
  const [formData, setFormData] = useState({
    name: 'Admin User',
    email: 'admin@meetingflow.com',
    language: 'pt-BR',
    timezone: 'America/Sao_Paulo',
    emailNotifications: true,
    minuteNotifications: true,
    processingNotifications: true,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Settings saved:', formData);
    alert('Configurações salvas com sucesso!');
  };

  const languageOptions = [
    { value: 'pt-BR', label: 'Português (Brasil)' },
    { value: 'en-US', label: 'English (US)' },
    { value: 'es-ES', label: 'Español' },
  ];

  const timezoneOptions = [
    { value: 'America/Sao_Paulo', label: 'Brasília (GMT-3)' },
    { value: 'America/Manaus', label: 'Manaus (GMT-4)' },
    { value: 'America/Fortaleza', label: 'Fortaleza (GMT-3)' },
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">Configurações</h1>
        <p className="text-gray-500 mt-1">Gerencie suas preferências e configurações da conta</p>
      </div>

      <form onSubmit={handleSubmit} className="max-w-4xl space-y-6">
        {/* Profile Settings */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <User className="w-5 h-5 text-gray-600" />
              <h2 className="text-lg font-semibold text-gray-900">Perfil</h2>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Nome"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
              <Input
                label="E-mail"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
          </CardContent>
        </Card>

        {/* Regional Settings */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-gray-600" />
              <h2 className="text-lg font-semibold text-gray-900">Regional</h2>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Select
                label="Idioma"
                value={formData.language}
                onChange={(e) => setFormData({ ...formData, language: e.target.value })}
                options={languageOptions}
              />
              <Select
                label="Fuso Horário"
                value={formData.timezone}
                onChange={(e) => setFormData({ ...formData, timezone: e.target.value })}
                options={timezoneOptions}
              />
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-gray-600" />
              <h2 className="text-lg font-semibold text-gray-900">Notificações</h2>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Notificações por E-mail</p>
                  <p className="text-sm text-gray-500">Receba atualizações por e-mail</p>
                </div>
                <input
                  type="checkbox"
                  checked={formData.emailNotifications}
                  onChange={(e) =>
                    setFormData({ ...formData, emailNotifications: e.target.checked })
                  }
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
              </label>

              <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Novas Atas</p>
                  <p className="text-sm text-gray-500">Notificar quando uma ata for gerada</p>
                </div>
                <input
                  type="checkbox"
                  checked={formData.minuteNotifications}
                  onChange={(e) =>
                    setFormData({ ...formData, minuteNotifications: e.target.checked })
                  }
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
              </label>

              <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">Status de Processamento</p>
                  <p className="text-sm text-gray-500">
                    Notificar sobre o progresso do processamento
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={formData.processingNotifications}
                  onChange={(e) =>
                    setFormData({ ...formData, processingNotifications: e.target.checked })
                  }
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
              </label>
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-gray-600" />
              <h2 className="text-lg font-semibold text-gray-900">Segurança</h2>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Button variant="secondary" type="button">
                  Alterar Senha
                </Button>
                <p className="text-sm text-gray-500 mt-2">
                  Última alteração: 15 de janeiro de 2026
                </p>
              </div>
              <div className="pt-4 border-t border-gray-200">
                <Button variant="secondary" type="button">
                  Configurar Autenticação de Dois Fatores
                </Button>
                <p className="text-sm text-gray-500 mt-2">
                  Adicione uma camada extra de segurança à sua conta
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4">
          <Button type="button" variant="secondary">
            Cancelar
          </Button>
          <Button type="submit">Salvar Alterações</Button>
        </div>
      </form>
    </div>
  );
}
