import { Card, CardHeader, CardContent } from '../components/Card';
import { MapPin, TrendingUp } from 'lucide-react';
import { regions } from '../data/mockData';

export function Regions() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">Regiões</h1>
        <p className="text-gray-500 mt-1">Gestão de regiões administrativas</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {regions.map((region) => (
          <Card key={region.id} className="hover:shadow-md transition-shadow">
            <CardContent className="py-6">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-blue-600" />
                </div>
                <div className="flex items-center gap-1 text-green-600">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-sm font-medium">{region.meetingCount}</span>
                </div>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-1">{region.name}</h3>
              <p className="text-sm text-gray-500 mb-4">{region.state}</p>
              <div className="pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Total de reuniões</span>
                  <span className="font-semibold text-gray-900">{region.meetingCount}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
