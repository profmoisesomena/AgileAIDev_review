export interface Region {
  id: string;
  name: string;
  state: string;
  meetingCount: number;
}

export interface Participant {
  id: string;
  name: string;
  photo: string;
  region: string;
  position: string;
  email: string;
  phone: string;
  status: 'active' | 'inactive';
  faceId?: string; // ID para reconhecimento facial
}

export interface Meeting {
  id: string;
  title: string;
  region: string;
  date: string;
  location: string;
  status: 'processing' | 'completed' | 'error' | 'pending';
  participants: string[];
  attendees?: string[]; // Participantes que compareceram (via reconhecimento facial)
  hasVideo: boolean;
  hasAudio: boolean;
  hasText: boolean;
  photos: string[];
  groupPhoto?: string; // Foto em grupo para reconhecimento facial
}

export interface Minute {
  id: string;
  meetingId: string;
  meetingTitle: string;
  region: string;
  date: string;
  agenda: string;
  summary: string;
  decisions: string[];
  actions: Array<{ description: string; responsible: string; deadline: string }>;
  approved: boolean;
}

export const regions: Region[] = [
  { id: '1', name: 'Região Norte', state: 'Amazonas', meetingCount: 12 },
  { id: '2', name: 'Região Sul', state: 'Rio Grande do Sul', meetingCount: 18 },
  { id: '3', name: 'Região Sudeste', state: 'São Paulo', meetingCount: 24 },
  { id: '4', name: 'Região Centro-Oeste', state: 'Goiás', meetingCount: 9 },
  { id: '5', name: 'Região Nordeste', state: 'Bahia', meetingCount: 15 },
];

export const participants: Participant[] = [
  {
    id: '1',
    name: 'Ana Silva',
    photo: 'https://images.unsplash.com/photo-1758599543120-4e462429a4d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjB3b21hbiUyMHByb2Zlc3Npb25hbCUyMGhlYWRzaG90fGVufDF8fHx8MTc3NDAxMjQ2MXww&ixlib=rb-4.1.0&q=80&w=1080',
    region: 'Região Sul',
    position: 'Coordenadora Regional',
    email: 'ana.silva@email.com',
    phone: '(51) 99999-1111',
    status: 'active',
    faceId: 'faceId1',
  },
  {
    id: '2',
    name: 'Carlos Santos',
    photo: 'https://images.unsplash.com/photo-1629507208649-70919ca33793?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMG1hbiUyMHBvcnRyYWl0JTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc3Mzk3MTg3Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    region: 'Região Sudeste',
    position: 'Gerente de Projetos',
    email: 'carlos.santos@email.com',
    phone: '(11) 98888-2222',
    status: 'active',
    faceId: 'faceId2',
  },
  {
    id: '3',
    name: 'Maria Oliveira',
    photo: 'https://images.unsplash.com/photo-1701463387028-3947648f1337?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMHBlcnNvbiUyMGF2YXRhcnxlbnwxfHx8fDE3NzM5ODU2NTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    region: 'Região Norte',
    position: 'Analista',
    email: 'maria.oliveira@email.com',
    phone: '(92) 97777-3333',
    status: 'active',
    faceId: 'faceId3',
  },
  {
    id: '4',
    name: 'João Pereira',
    photo: 'https://images.unsplash.com/photo-1629507208649-70919ca33793?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMG1hbiUyMHBvcnRyYWl0JTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc3Mzk3MTg3Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    region: 'Região Nordeste',
    position: 'Supervisor',
    email: 'joao.pereira@email.com',
    phone: '(71) 96666-4444',
    status: 'active',
    faceId: 'faceId4',
  },
  {
    id: '5',
    name: 'Fernanda Costa',
    photo: 'https://images.unsplash.com/photo-1758599543120-4e462429a4d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjB3b21hbiUyMHByb2Zlc3Npb25hbCUyMGhlYWRzaG90fGVufDF8fHx8MTc3NDAxMjQ2MXww&ixlib=rb-4.1.0&q=80&w=1080',
    region: 'Região Centro-Oeste',
    position: 'Consultora',
    email: 'fernanda.costa@email.com',
    phone: '(62) 95555-5555',
    status: 'active',
    faceId: 'faceId5',
  },
];

export const meetings: Meeting[] = [
  {
    id: '1',
    title: 'Planejamento Trimestral 2026 - Região Sul',
    region: 'Região Sul',
    date: '2026-03-15T14:00:00',
    location: 'Sala de Conferências Porto Alegre',
    status: 'completed',
    participants: ['1', '2'],
    attendees: ['1', '2'], // Presença confirmada via reconhecimento facial
    hasVideo: true,
    hasAudio: true,
    hasText: true,
    photos: [
      'https://images.unsplash.com/photo-1633431303895-8236f0a04b46?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWV0aW5nJTIwY29uZmVyZW5jZSUyMHJvb20lMjBidXNpbmVzc3xlbnwxfHx8fDE3NzQwMTI0NjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1758691736843-90f58dce465e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjB0ZWFtJTIwY29sbGFib3JhdGlvbiUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NzQwMTI0NjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    ],
    groupPhoto: 'https://images.unsplash.com/photo-1552664730-d307ca884978?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFtJTIwbWVldGluZyUyMGdyb3VwJTIwcGhvdG98ZW58MXx8fHwxNzc0MDEyNDYzfDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: '2',
    title: 'Revisão de Processos - Região Sudeste',
    region: 'Região Sudeste',
    date: '2026-03-18T10:00:00',
    location: 'Escritório São Paulo',
    status: 'processing',
    participants: ['2', '3'],
    hasVideo: true,
    hasAudio: false,
    hasText: true,
    photos: [],
  },
  {
    id: '3',
    title: 'Alinhamento Estratégico - Região Norte',
    region: 'Região Norte',
    date: '2026-03-20T09:00:00',
    location: 'Centro de Convenções Manaus',
    status: 'pending',
    participants: ['3', '4'],
    hasVideo: false,
    hasAudio: true,
    hasText: false,
    photos: [],
  },
  {
    id: '4',
    title: 'Apresentação de Resultados - Região Nordeste',
    region: 'Região Nordeste',
    date: '2026-02-28T15:30:00',
    location: 'Auditório Salvador',
    status: 'completed',
    participants: ['4', '5'],
    attendees: ['4'], // Apenas João compareceu
    hasVideo: true,
    hasAudio: true,
    hasText: true,
    photos: [],
  },
];

export const minutes: Minute[] = [
  {
    id: '1',
    meetingId: '1',
    meetingTitle: 'Planejamento Trimestral 2026 - Região Sul',
    region: 'Região Sul',
    date: '2026-03-15T14:00:00',
    agenda: 'Discussão sobre objetivos e metas para o primeiro trimestre de 2026, análise de recursos necessários e definição de prazos.',
    summary: 'A reunião teve como foco principal o planejamento estratégico do primeiro trimestre. Foram discutidas as metas de crescimento, alocação de recursos e cronograma de atividades. Todos os participantes contribuíram com sugestões para otimização dos processos.',
    decisions: [
      'Aumento de 15% no orçamento de marketing',
      'Contratação de 3 novos analistas para a equipe',
      'Implementação de novo sistema de gestão até abril',
    ],
    actions: [
      {
        description: 'Preparar proposta de orçamento detalhada',
        responsible: 'Ana Silva',
        deadline: '2026-03-25',
      },
      {
        description: 'Iniciar processo seletivo',
        responsible: 'Carlos Santos',
        deadline: '2026-03-30',
      },
      {
        description: 'Avaliar fornecedores de software',
        responsible: 'Ana Silva',
        deadline: '2026-04-05',
      },
    ],
    approved: true,
  },
  {
    id: '2',
    meetingId: '4',
    meetingTitle: 'Apresentação de Resultados - Região Nordeste',
    region: 'Região Nordeste',
    date: '2026-02-28T15:30:00',
    agenda: 'Apresentação dos resultados do último trimestre de 2025 e análise comparativa com período anterior.',
    summary: 'Foram apresentados os indicadores de desempenho do último trimestre, demonstrando crescimento de 12% em relação ao trimestre anterior. A equipe destacou os principais desafios enfrentados e as estratégias que trouxeram melhores resultados.',
    decisions: [
      'Manter estratégia atual de vendas',
      'Expandir atuação para mais 2 cidades',
      'Realizar treinamento da equipe em abril',
    ],
    actions: [
      {
        description: 'Mapear potenciais cidades para expansão',
        responsible: 'João Pereira',
        deadline: '2026-03-15',
      },
      {
        description: 'Elaborar programa de treinamento',
        responsible: 'Fernanda Costa',
        deadline: '2026-03-20',
      },
    ],
    approved: true,
  },
];