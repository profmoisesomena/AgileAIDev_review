Crie o design de uma aplicação web moderna, responsiva e profissional para gestão de reuniões regionais com geração automática de atas a partir de vídeo, áudio e texto.

### Estilo visual

* Interface limpa e moderna (inspirada em SaaS como Notion, Airtable e Slack)
* Uso de cores neutras com destaque em azul ou verde
* Tipografia clara e legível
* Layout com sidebar fixa à esquerda e conteúdo principal à direita
* Componentes com bordas suaves e sombras leves
* Design responsivo (desktop prioritário)

---

### Estrutura geral do sistema

A aplicação deve conter os seguintes módulos no menu lateral:

1. Dashboard
2. Regiões
3. Participantes
4. Reuniões
5. Atas
6. Relatórios
7. Configurações

---

### Tela 1: Dashboard

* Cards com métricas:

  * número de reuniões
  * reuniões por região
  * atas geradas
  * reuniões pendentes de processamento
* Gráfico de reuniões por mês
* Lista das últimas reuniões
* Botão destacado: "Nova Reunião"

---

### Tela 2: Lista de Participantes

* Tabela com:

  * foto (avatar)
  * nome
  * região
  * cargo
  * status
* Campo de busca
* Filtro por região
* Botão "Adicionar Participante"

---

### Tela 3: Cadastro de Participante

* Formulário com:

  * nome completo
  * upload de foto (preview circular)
  * região (select)
  * cargo/função
  * email
  * telefone
* Botões: salvar e cancelar

---

### Tela 4: Lista de Reuniões

* Tabela com:

  * título
  * região
  * data
  * status (processando, concluída, erro)
* Filtros por:

  * região
  * data
  * status
* Botão "Nova Reunião"

---

### Tela 5: Cadastro de Reunião

* Formulário dividido em seções:

#### Informações básicas

* título
* região
* data e hora
* local

#### Participantes

* seleção múltipla com fotos (avatar + nome)

#### Upload de conteúdos

* área de upload com drag and drop para:

  * vídeo
  * áudio
* campo para texto manual (textarea grande)

#### Fotos da reunião

* upload de múltiplas imagens com preview em grid

* Botão principal: "Processar Reunião"

---

### Tela 6: Processamento / Status

* Indicador de progresso:

  * upload concluído
  * transcrição em andamento
  * geração da ata
* Barra de progresso
* Status em tempo real

---

### Tela 7: Visualização da Reunião

Layout dividido em 3 colunas:

#### Coluna 1

* informações da reunião
* participantes com fotos

#### Coluna 2

* transcrição completa (editável)

#### Coluna 3

* ata gerada automaticamente com seções:

  * pauta
  * resumo
  * decisões
  * encaminhamentos

* Botões:

  * editar
  * aprovar ata
  * exportar PDF

---

### Tela 8: Galeria de Fotos da Reunião

* Grid com imagens
* opção de expandir imagem
* legenda opcional

---

### Tela 9: Relatórios

* filtros por região e período
* gráficos de:

  * reuniões por região
  * participação
* exportação

---

### Componentes reutilizáveis

* botões primários e secundários
* inputs
* select
* upload drag-and-drop
* avatar com imagem
* badges de status
* cards
* tabelas

---

### Extras importantes

* estados de loading
* estados vazios (empty state)
* mensagens de erro
* design consistente entre telas

---

### Objetivo do design

Criar uma interface intuitiva que permita:

* cadastrar participantes com foto
* registrar reuniões com vídeo, áudio e texto
* gerar automaticamente atas estruturadas
* visualizar e editar conteúdos de forma simples

---

Crie todas as telas com layout consistente e pronto para prototipação no Figma.
